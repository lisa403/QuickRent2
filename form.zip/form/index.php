<?php
session_start();

function validateInput($data) {
    $data = trim($data); 
    $data = stripslashes($data); 
    $data = htmlspecialchars($data); 
    return $data;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QuickRent - Rental Mobil & Motor Purwokerto</title>
    <link rel="stylesheet" href="style.css">
    <style>
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .auth-section:target .auth-content {
            animation: fadeInUp 0.5s;
        }
        
        .popup {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: #fff;
            padding: 20px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.3);
            border-radius: 8px;
            z-index: 1000;
        }
        .popup button {
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="logo">
                <h1>Quick<span>Rent</span></h1>
            </div>
            <ul class="nav-links">
                <li><a href="#home">Beranda</a></li>
                <li><a href="#about">Tentang Kami</a></li>
                <li><a href="#reviews">Ulasan</a></li>
                <li><a href="#contact">Kontak</a></li>
                <li><a href="#login-section" class="auth-link">Masuk</a></li>
                <li><a href="#register-section" class="auth-link">Daftar</a></li>
            </ul>
        </nav>
    </header>

    <section id="home" class="hero">
        <div class="hero-overlay"></div>
        <div class="hero-content">
        <div class="container">
        <div class="booking-card">
            <div class="car-image">
            <img src="images/Air-Green-1.png" alt="Wuling Air Ev">
        </div>
        <div class="booking-form">
        <div class="car-title">Wuling Air Ev</div>
        <div class="car-specs">
            <div class="car-spec">👫 <span>2 Orang</span></div>
            <div class="car-spec">📅 <span>2022</span></div>
            <div class="car-spec">🚗 <span>Listrik</span></div>
        </div>

        <form action="proses_pemesanan.php" method="POST">
        <div class="form-group">
            <label for="alamat">Alamat Pengambilan/Penjemputan</label>
            <select name="alamat" id="alamat" class="form-control">
                <option value="Purwokerto Timur">📍Purwokerto Timur</option>
                <option value="Purwokerto Barat">📍Purwokerto Barat</option>
                <option value="Purwokerto Barat">📍Purwokerto Utara</option>
                <option value="Purwokerto Barat">📍Purwokerto Selatan</option>
            </select>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label for="tanggal_ambil">Tanggal Pengantaran</label>
                <input type="date" name="tanggal_ambil" class="form-control">
            </div>
            <div class="form-group">
                <label for="jam_ambil">Jam</label>
                <input type="time" name="jam_ambil" value="05:00" class="form-control">
            </div>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label for="tanggal_kembali">Tanggal Pengembalian</label>
                <input type="date" name="tanggal_kembali" class="form-control">
            </div>
            <div class="form-group">
                <label for="jam_kembali">Jam</label>
                <input type="time" name="jam_kembali" value="07:00" class="form-control">
            </div>
        </div>

        <div class="form-group">
            <label for="durasi">Durasi Sewa</label>
            <select name="durasi" class="form-control">
                <option value="1 Hari">1 Hari</option>
                <option value="2 Hari">2 Hari</option>
                <option value="3 Hari">3 Hari</option>
                <option value="4 Hari">4 Hari</option>
                <option value="5 Hari">5 Hari</option>
                <option value="6 Hari">6 Hari</option>
                <option value="1 Minggu">1 Minggu</option>
            </select>
        </div>

            <a href="#bookingPopup" class="btn-primary">Rental Sekarang</a>
            </form>
        </div>
    </div>
    <div id="bookingPopup" class="popup">
  <div class="popup-content">
    <a href="#" class="close-btn">&times;</a>
    <h2>Detail Booking</h2>
    <img src="assets/images/Air-Green-1.png" alt="Mobil" style="width: 100px;">
    <p>Wuling Air Ev | 2023</p>
    <p>Tanggal Sewa : dd/mm/yyyy</p>
    <p>Durasi Sewa : 1 Hari</p>
    <p>Jumlah Sewa : 1 Unit</p>
    <p>Harga Total : Rp 800.000</p>

    <h3>Detail Customer</h3>
    <form>
      <input type="text" placeholder="Nama Lengkap" class="form-control"><br>
      <input type="text" placeholder="NIK" class="form-control"><br>
      <input type="text" placeholder="Nomor Telepon" class="form-control"><br>
      <input type="email" placeholder="E-mail" class="form-control"><br><br>
      <strong>Grand Total: Rp 800.000</strong><br><br>
      <button type="submit" class="btn-primary">Konfirmasi</button>
    </form>
  </div>
</div>

    <script>
        // Set default dates to today and tomorrow
        document.addEventListener('DOMContentLoaded', function() {
            const today = new Date();
            const tomorrow = new Date(today);
            tomorrow.setDate(tomorrow.getDate() + 1);
            
            // Format dates for input
            const formatDate = (date) => {
                const year = date.getFullYear();
                const month = String(date.getMonth() + 1).padStart(2, '0');
                const day = String(date.getDate()).padStart(2, '0');
                return `${year}-${month}-${day}`;
            };
            
            document.getElementById('pickup-date').value = formatDate(today);
            document.getElementById('return-date').value = formatDate(tomorrow);
        });
    </script>
</body>
</html>