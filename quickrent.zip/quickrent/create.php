<?php
require 'config.php';
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pengguna_id = $_POST['pengguna_id'];
    $vehicle_id = $_POST['vehicle_id'];
    $tanggal_penyewa = $_POST['tanggal_penyewa'];
    $tanggal_dikembalikan = $_POST['tanggal_dikembalikan'];
    $total_harga = $_POST['total_harga'];
    $status = $_POST['status'];

    $stmt = $pdo->prepare("INSERT INTO pemesanan (pengguna_id, vehicle_id, tanggal_penyewa, tanggal_dikembalikan, total_harga, status) VALUES (?, ?, ?, ?, ?, ?)");
    if ($stmt->execute([$pengguna_id, $vehicle_id, $tanggal_penyewa, $tanggal_dikembalikan, $total_harga, $status])) {
        $message = "Pemesanan berhasil ditambahkan!";
    } else {
        $message = "Terjadi kesalahan saat menyimpan.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tambah Pemesanan - QuickRent</title>
</head>
<body>
    <h1>Tambah Pemesanan Baru</h1>
    <?php if ($message): ?>
        <p><?= $message ?></p>
    <?php endif; ?>
    <form method="POST">
        <label>ID Pengguna:</label><br>
        <input type="number" name="pengguna_id" required><br>

        <label>ID Kendaraan:</label><br>
        <input type="number" name="vehicle_id" required><br>

        <label>Tanggal Sewa:</label><br>
        <input type="date" name="tanggal_penyewa" required><br>

        <label>Tanggal Kembali:</label><br>
        <input type="date" name="tanggal_dikembalikan" required><br>

        <label>Total Harga:</label><br>
        <input type="number" name="total_harga" required><br>

        <label>Status:</label><br>
        <select name="status" required>
            <option value="pending">Pending</option>
            <option value="confirmed">Confirmed</option>
            <option value="cancelled">Cancelled</option>
            <option value="completed">Completed</option>
        </select><br><br>

        <button type="submit">Simpan</button>
    </form>
</body>
</html>
