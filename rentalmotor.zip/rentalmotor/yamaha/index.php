<?php
session_start();

function validateInput($data) {
    $data = trim($data); 
    $data = stripslashes($data); 
    $data = htmlspecialchars($data); 
    return $data;
}

$vehicles = [
    [
        'name' => 'Yamaha Mio M3',
        'image' => 'images/mio.png',
        'price' => 70000,
        'rating' => 4.2,
        'reviews' => 150
    ],
    [
        'name' => 'Yamaha Gear 125',
        'image' => 'images/gear.png',
        'price' => 75000,
        'rating' => 4.5,
        'reviews' => 196
    ],
    [
        'name' => 'Yamaha Fazzio',
        'image' => 'images/fazzio.png',
        'price' => 100000,
        'rating' => 4.5,
        'reviews' => 326
    ],
    [
        'name' => 'Yamaha NMAX',
        'image' => 'images/nmax.png',
        'price' => 140000,
        'rating' => 4.2,
        'reviews' => 150
    ],
    [
        'name' => 'Yamaha Jupiter Z1',
        'image' => 'images/jupiter.png',
        'price' => 60000,
        'rating' => 4.8,
        'reviews' => 200
    ]
];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QuickRent - Rental Mobil & Motor Purwokerto</title>
    <link rel="stylesheet" href="style.css">
    <style>
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .auth-section:target .auth-content {
            animation: fadeInUp 0.5s;
        }
        
        .popup {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: #fff;
            padding: 20px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.3);
            border-radius: 8px;
            z-index: 1000;
        }
        .popup button {
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="logo">
                <h1>Quick<span>Rent</span></h1>
            </div>
            <ul class="nav-links">
                <li><a href="#home">Beranda</a></li>
                <li><a href="#about">Tentang Kami</a></li>
                <li><a href="#reviews">Ulasan</a></li>
                <li><a href="#contact">Kontak</a></li>
                <li><a href="#login-section" class="auth-link">Masuk</a></li>
                <li><a href="#register-section" class="auth-link">Daftar</a></li>
            </ul>
        </nav>
    </header>

    <section id="home" class="hero">
        <div class="hero-overlay"></div>
        <div class="hero-content">
            <h1>Temukan solusi transportasi terbaik untuk kebutuhan Anda di Purwokerto dengan harga terjangkau dan pelayanan prima</h1>
        </div>
    </section>
        
    <section class="vehicle-results">
        <h2 class="section-title">Pencarian Unit (5)</h2>
        <div class="vehicle-grid" id="vehicle-list">
        <?php foreach ($vehicles as $vehicle): ?>
            <div class="vehicle-card">
                <img src="<?php echo $vehicle['image']; ?>" alt="<?php echo $vehicle['name']; ?>">
                <div class="vehicle-info">
                    <div class="rating">
                        <?php for ($i = 0; $i < 5; $i++): ?>
                            <span class="star <?php echo $i < floor($vehicle['rating']) ? 'filled' : 'half-filled'; ?>">★</span>
                        <?php endfor; ?>
                        <span class="review-count">(<?php echo $vehicle['reviews']; ?>)</span>
                    </div>
                    <h3><?php echo $vehicle['name']; ?></h3>
                    <hr>
                    <p class="price">Rp<?php echo number_format($vehicle['price'], 0, ',', '.'); ?> <span class="per-day">/Per Hari</span></p>
                    <form method="post" action="">
                        <input type="hidden" name="vehicle_name" value="<?php echo $vehicle['name']; ?>">
                        <input type="hidden" name="vehicle_type" value="mobil"> 
                        <button type="submit" name="rent_now" class="sewa-sekarang">Sewa Sekarang <span class="arrow">›</span></button>
                    </form>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
    </section>


    <section id="login-section" class="auth-section">
        <div class="auth-container">
            <div class="auth-content">
                <a href="#" class="close-button">&times;</a>
                <h2>Masuk</h2>
                <form class="auth-form" action="popup.php" method="POST">
                    <div class="form-group">
                        <label for="login-email">Email</label>
                        <input type="email" id="login-email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label for="login-password">Password</label>
                        <input type="password" id="login-password" name="password" required>
                    </div>
                    <div class="form-group remember-me">
                        <input type="checkbox" id="remember" name="remember">
                        <label for="remember">Ingat Saya</label>
                    </div>
                    <button type="submit" class="auth-button">Masuk</button>
                    <p class="forgot-password"><a href="#forgot-section">Lupa password?</a></p>
                    <p class="switch-form">Belum punya akun? <a href="#register-section">Daftar disini</a></p>
                </form>
            </div>
        </div>
    </section>

    <section id="register-section" class="auth-section">
        <div class="auth-container">
            <div class="auth-content">
                <a href="#" class="close-button">&times;</a>
                <h2>Daftar</h2>
                <form class="auth-form" action="#" method="POST">
                    <div class="form-group">
                        <label for="register-name">Nama Lengkap</label>
                        <input type="text" id="register-name" name="name" required>
                    </div>
                    <div class="form-group">
                        <label for="register-email">Email</label>
                        <input type="email" id="register-email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label for="register-phone">No. HP</label>
                        <input type="tel" id="register-phone" name="phone" required>
                    </div>
                    <div class="form-group">
                        <label for="register-password">Password</label>
                        <input type="password" id="register-password" name="password" required>
                    </div>
                    <div class="form-group">
                        <label for="register-confirm-password">Konfirmasi Password</label>
                        <input type="password" id="register-confirm-password" name="confirm_password" required>
                    </div>
                    <div class="form-group terms">
                        <input type="checkbox" id="terms" name="terms" required>
                        <label for="terms">Saya menyetujui <a href="#">Syarat dan Ketentuan</a></label>
                    </div>
                    <button type ="submit" class="auth-button">Daftar</button>
                    <p class="switch-form">Sudah punya akun? <a href="#login-section">Masuk disini</a></p>
                </form>
            </div>
        </div>
    </section>

    <section id="forgot-section" class="auth-section">
        <div class="auth-container">
            <div class="auth-content">
                <a href="#" class="close-button">&times;</a>
                <h2>Lupa Password</h2>
                <form class="auth-form" action="#" method="POST">
                    <div class="form-group">
                        <label for="forgot-email">Email</label>
                        <input type="email" id="forgot-email" name="email" required>
                    </div>
                    <button type="submit" class="auth-button">Reset Password</button>
                    <p class="switch-form"><a href="#login-section">Kembali ke halaman login</a></p>
                </form>
            </div>
        </div>
    </section>

    <footer>
  <div class="footer-container">
    <!-- QuickRent -->
    <div class="footer-section">
      <h3>QuickRent</h3>
      <p>Kami melayani sewa sesuai dengan opsi kebutuhan Anda yaitu per 12 jam, 24 jam, harian, mingguan, dan bulanan.</p>
      <p>Menyediakan layanan rental mobil dan motor berkualitas dengan pilihan kendaraan terlengkap, harga terjangkau, dan proses pemesanan yang mudah untuk memenuhi kebutuhan transportasi Anda selama di kota ini, kami ahlinya.</p>
    </div>

    <!-- Kontak Kami -->
    <div class="footer-section">
      <h3>Kontak Kami</h3>
      <p><strong>Alamat:</strong> Jl. Kauman Lama No.26, Purwokerto Barat, Jawa Tengah</p>
      <p><strong>Telp:</strong> 0812-9283-9982</p>
      <p><strong>Email:</strong> vionasptrsduasa@quickrent.com</p>
      <p><strong>Jam Operasional:</strong> Senin - Minggu: 08.00 - 22.00</p>
      <h4>Sosial Media</h4>
      <div class="social-icons">
        <a href="https://wa.me/6289508847208" target="_blank">
          <img src="images/whatsapp-icon.png" alt="WhatsApp">
        </a>
        <a href="https://www.instagram.com/quickrent_" target="_blank">
          <img src="images/instagram-icon.png" alt="Instagram">
        </a>
      </div>
    </div>

    <!-- Alamat & Peta -->
    <div class="footer-section">
      <h3>Alamat</h3>
      <iframe class="footer-map" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3952.649279983177!2d109.23354097584553!3d-7.827653192181254!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e655efb6df5f47b%3A0xb7a607ff4d88828f!2sJl.%20Kauman%20Lama%20No.26%2C%20Purwokerto%20Bar.%2C%20Kabupaten%20Banyumas!5e0!3m2!1sid!2sid!4v1714458121123!5m2!1sid!2sid"
                allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
  </div>
  <div class="footer-bottom">© 2024 QuickRent. All rights reserved.</div>
</footer>
</body>
</html>

    